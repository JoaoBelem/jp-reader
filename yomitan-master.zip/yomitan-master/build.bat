@npm run-script build -- %*
